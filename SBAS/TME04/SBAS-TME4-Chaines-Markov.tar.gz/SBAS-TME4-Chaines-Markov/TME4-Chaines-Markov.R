#Matrice de transition P159
P159 = matrix(c(0.58,0.35,0.07,0.01,0.99,0,0.04,0.49,0.47), nrow = 3, ncol = 3, byrow=TRUE)
dimnames(P159)=list(c("SL","Basal","Luminal"), c("SL","Basal","Luminal"))
P159

#Matrice de transition P149
P149=matrix(c(0.61,0.09,0.3,0.01,0.9,0.08,0.01,0,0.99), nrow = 3, ncol = 3, byrow=TRUE)
dimnames(P149)=list(c("SL","Basal","Luminal"), c("SL","Basal","Luminal"))
P149

#fonction pour calculer la puissance des matrices
pow <- function(mat,pow){
t <- mat
for ( i in 1:(pow-1)){
t <- mat%*%t
}
return(t)
}

#Determination des etats stationnaires methode1: convergence pour pi0=(0.998,0.001,0.001)
pi0<-c(0.998,0.001,0.001)
P159conv<-pi0%*%pow(P159,200)
P159conv
P149conv<-pi0%*%pow(P149,200)
P149conv

#Determination des etats stationnaires methode2: vecteur propre pour lamda=1
vectLamda1=function(matrice){
Pconv<-eigen(matrice)$vectors[,which.max(eigen(matrice)$values)];
print(Pconv)}

eigen(P159)
vectLamda1(P159)
eigen(P149)
vectLamda1(P149)

#matrice de transition pour n iterations
transitionN=function(n){
data_n<-data.frame(P159=pow(P159, n), P149=pow(P149,n))}
for (n in c(2,4,8,16,32,64)){
print(data.frame(n,transitionN(n)))}

#Probabilité d'une chaine de markov à trois états
 
Markovchain=function(pi0, matrice){
SL<-vector()
basal<-vector()
luminal<-vector()
pi<-vector()
for (n in 0:20){
pi = pi0%*%pow(matrice,n)
SL[n]=pi[c(1)]
basal[n]=pi[c(2)]
luminal[n]=pi[c(3)]}; data=rbind(SL,basal,luminal);dimnames(data)=list(c("SL","Basal","Luminal")); print(data);
x<-c(1:20)
cells<-data.frame(SL, basal, luminal)
matplot(x,cells, type="b", ylab="Probabilités des lignées cellulaires",
     xlab="Nombre d'iterations",main="Markov chain", 
     lty=c(1,1,1), lwd=c(3,3,3),pch=c(15,15,15), col=c("brown3","chartreuse3","darkblue")
     )
 legend("topright",1, max(cells),legend=colnames(cells),        
    col=c("brown3","chartreuse3","darkblue"),
        lty=c(1,1,1), lwd=c(3,3,3),pch=c(15,15,15)
    )
}

#pi01=(0.998,0.001,0.001)
pi01<-c(0.998,0.001,0.001)
Markovchain(pi01, P159)
Markovchain(pi01, P149)
#pi02=(0.001,0.998,0.001)
pi02<-c(0.001,0.998,0.001)
Markovchain(pi02, P159)
Markovchain(pi02, P149)
#pi03=(0.001,0.001,0.998)
pi03<-c(0.001,0.001,0.998)
Markovchain(pi03, P159)
Markovchain(pi03, P149)

#trajectoire stochastique d'une seule realisation de la chaine de markov
Trajectoire=function(pi0,Titerations, matrice){
n <- Titerations
traj <- numeric(n)
x <- sample(1:3, 1, prob=pi0)   # etat actuel
traj[1] <- x
for(i in 2:n){
    x <- sample(1:3, 1, prob = matrice[x,])  # nouvel etat
    traj[i] <- x
}

print(traj)
table(traj)
moyenne<-table(traj)/length(traj)
print(moyenne)}


Trajectoire1=function(pi0,Titerations, matrice){
n <- Titerations
traj <- numeric(n)
x <- sample(1:3, 1, prob=pi0)   # etat actuel
traj[1] <- x
for(i in 2:n){
    x <- sample(1:3, 1, prob = matrice[x,])  # nouvel etat
    traj[i] <- x
};return (traj)}

# trajectoire stochastique de N population 
sommeEtat=function(column, etat,Num){
somme =0
for (i in column){if (i == etat) {somme<-somme+i}};moyenne=somme/Num; return (moyenne);}


TrajectoirePop=function(pi0,Titerations, matrice, Num, etat){
VectPop<-matrix(data = NA, nrow= Num, ncol= Titerations)
vect1<-vector()
moyenneTraj<-matrix(data=NA, nrow=1, ncol=Titerations)
for (i in 1:Num){
vect1<-Trajectoire1(pi0,Titerations, matrice)
VectPop[i,]<-vect1}
for (i in 1:Titerations){moyenneTraj[,i]<-c(sommeEtat(VectPop[,i], etat, Num))
};return (moyenneTraj)
}
#Etats
SL=1
basal=2
luminal=3
TrajectoirePop(pi01,20,P159,100, SL)

#Graphic des courbes de probabilité pour N populations 

PlotStochastic=function(pi0,Titerations, matrice, Num){
iter <- c(1:Titerations)
nSL <- TrajectoirePop(pi0,Titerations, matrice, Num, SL)
nBasal<-TrajectoirePop(pi0,Titerations, matrice, Num, basal)
nLuminal<-TrajectoirePop(pi0,Titerations, matrice, Num, luminal)

cells <- data.frame(SL=t(nSL), Basal=t(nBasal), Luminal=t(nLuminal))
matplot(iter, cells, type="b", ylab="lignées cellulaires pour N population",
    xlab="Nombre d'iterations",main="Markov chain Npopulation", 
    lty=c(1,1,1), lwd=c(3,3,3),pch=c(15,15,15), col=c("brown3","chartreuse3","darkblue")
    )
legend("topright",1, max(cells),legend=colnames(cells),        
    lty=c(1,1,1), lwd=c(3,3,3),pch=c(15,15,15), fill=c("brown3","chartreuse3","darkblue")
    )
}

Titerations<-20
N<-10000

#pi01=(0.998,0.001,0.001)
PlotStochastic(pi01,Titerations,P159,N)
PlotStochastic(pi01,Titerations,P149,N)
#pi02=(0.001,0.998,0.001)
PlotStochastic(pi02,Titerations,P159,N)
PlotStochastic(pi02,Titerations,P149,N)
#pi03=(0.001,0.001,0.998)
PlotStochastic(pi02,Titerations,P159,N)
PlotStochastic(pi02,Titerations,P149,N)


#plot pour N=10,100,1000,10000
plotNstochastique=function(etat, pi0, Titerations, matrice){
netat10<-TrajectoirePop(pi0,Titerations, matrice, 10, etat)
netat100<-TrajectoirePop(pi0,Titerations, matrice, 100, etat)
netat1000<-TrajectoirePop(pi0,Titerations, matrice, 1000, etat)
netat10000<-TrajectoirePop(pi0,Titerations, matrice, 10000, etat)
data_etat <- data.frame(N10=t(netat10), N100=t(netat100), N1000=t(netat1000), N10000=t(netat10000))
iter<-c(1:20)
matplot(iter,data_etat, type="b", ylab="Probabilités de la lignée cellulaire pour N population de 10 à 10000",
    xlab="Nombre d'iterations",main="Trajectoire stochastique", 
    lty=c(1,1,1), lwd=c(3,3,3),pch=c(15,15,15), col=c("brown3","chartreuse3","darkblue")
    )
legend("topright",1, max(data_etat),legend=colnames(data_etat),        
    lty=c(1,1,1), lwd=c(3,3,3),pch=c(15,15,15), fill=c("brown3","chartreuse3","darkblue"))
}

plotNstochastique(SL, pi01, Titerations, P149)
plotNstochastique(basal, pi01, Titerations, P149)
plotNstochastique(luminal, pi01, Titerations, P149)

#pour un etat SL fixé on compare la difference en fonction de pi0
showplot=function(dataframe){
iter<-c(1:20)
matplot(iter,data_etat1, type="b", ylab="Probabilités de la lignée cellulaire pour N population pour differentes probabilités initiales",
    xlab="Nombre d'itérations", main="Trajectoire stochastique pour différentes probabilités initiales", 
     lty=c(1,1,1), lwd=c(3,3,3),pch=c(15,15,15), col=c("brown3","chartreuse3","darkblue"))
legend("topright",1, max(data_etat1),legend=colnames(data_etat1),        
     lty=c(1,1,1), lwd=c(3,3,3),pch=c(15,15,15), fill=c("brown3","chartreuse3","darkblue"))
}

netat01<--TrajectoirePop(pi01,Titerations, P159, N, SL)
netat02<--TrajectoirePop(pi02,Titerations, P159, N, SL)
netat03<--TrajectoirePop(pi03,Titerations, P159, N, SL)
data_etat1<- data.frame(pi01=t(netat01), pi02=t(netat02) ,pi03= t(netat03))
showplot(data_etat1)


#Calcul de la probabilité d'une trajectoire

etat_suivant=function(matrice, lignee){
AccSL<-c(cumsum(data.frame(t(matrice))$SL))
Accbasal<-c(cumsum(data.frame(t(matrice))$Basal))
Accluminal<-c(cumsum(data.frame(t(matrice))$Luminal))
Accmatrix<-data.frame(AccSL,Accbasal,Accluminal)
vect<-as.numeric(Accmatrix[lignee,])
y<-runif(1,0,1)
max_vect<-max(vect)
ind_max_vect<-match(max_vect, vect)
min_vect<-min(vect)
ind_min_vect<-match(min_vect, vect)

if (y>= min(vect[1],vect[2])&& y< max(vect[1], vect[2])){;return (1)}
if (y>= min(vect[2],vect[3])&& y< max(vect[2], vect[3])){;return(2)}
if(y>max_vect){; return (ind_max_vect)}
if (y<min_vect){; return (ind_min_vect)}}

chMarkov=function(lignee, Titerations, matrice){
chaine<-matrix(data=NA,1,Titerations)
chaine[1]<-c(lignee)
chaine[2]<-etat_suivant(matrice,lignee)
for (i in 3:Titerations){chaine[i]<-etat_suivant(matrice,chaine[i-1])}; return(chaine)}


PopchMarkov=function(lignee, Titerations, matrice, N){
popvect<-matrix(data=NA, nrow=N, ncol=Titerations)
for(i in 1:N){popvect[i,]<-chMarkov(lignee, Titerations, matrice)}; return (popvect)}

N=10000
Titerations=20
popSL<-PopchMarkov(SL, Titerations, P159, N) 
popBasal<-PopchMarkov(basal, Titerations, P159, N) 
popLuminal<-PopchMarkov(luminal, Titerations, P159, N) 

#trajectoire moyenne de chaque population
TrajectoireMoy=function(etat, Titerations, matrice, N){
VectPop<-matrix(data = NA, nrow= N, ncol= Titerations)
vect1<-vector()
moyenneTraj<-matrix(data=NA, nrow=1, ncol=Titerations)
for (i in 1:N){
vect1<-PopchMarkov(etat, Titerations, matrice, N) [i,]
VectPop[i,]<-vect1}
for (i in 1:Titerations){moyenneTraj[,i]<-c(sommeEtat(VectPop[,i], etat, N))
};return (moyenneTraj)
}

matrice = P149
Num = 100
iter = c(1:20)
trajSL<-TrajectoireMoy(SL, Titerations, matrice, Num)
trajBasal<-TrajectoireMoy(basal, Titerations, matrice, Num)
trajLuminal<-TrajectoireMoy(luminal, Titerations, matrice, Num)

traj_data <- data.frame(SL=t(trajSL), Basal=t(trajBasal), Luminal= t(trajLuminal))
matplot(iter,traj_data, type="b", ylab="trajectoire moyenne pour chaque population",xlab="Nombre d'itérations", main="Trajectoire moyenne de chaque population P149, N=100", lty=c(1,1,1), lwd=c(3,3,3),pch=c(15,15,15), col=c("brown3","chartreuse3","darkblue"))
legend("topright",1, max(traj_data),legend=colnames(traj_data),lty=c(1,1,1), lwd=c(3,3,3),pch=c(15,15,15), fill=c("brown3","chartreuse3","darkblue"))
plot()



proba_chaine=function(chaine, matrice){
proba<-matrix(data=NA, 1, length(chaine))
for (n in 1:length(chaine)){
ind_act<-chaine[n]
ind_suiv<-chaine[n+1]
prob<-log((matrice[ind_act,][ind_suiv]))
proba[n]<- prob
proba[length(chaine)]<-0}; 
return (sum(proba))}

N=10000
proba_traj1=function(pop,matrice, Titerations, N){
vectpop<-matrix(data=NA, nrow=1, ncol=N)
for (i in 1:N){
vectpop[i]<-proba_chaine(pop[i,], matrice)
}; return (vectpop) 
}


probaSL<-proba_traj1(popSL, t(P159),Titerations, N)
probaBasal<-proba_traj1(popBasal, t(P159), Titerations, N)
probaLuminal<-proba_traj1(popLuminal, t(P159),Titerations, N)


set.seed(50)
p1<-hist(probaSL, col="brown3", xlim=c(-25,-5), ylim=c(0,1000), xlab="Probabilité",main="Probablités des trajectoires P159 N10000")
p2<-hist(probaBasal, col="chartreuse3", xlim=c(-25,-5),ylim=c(0,1000),  xlab="Probabilité",main="Probablités des trajectoires P159 N10000", add=T)
p3<-hist(probaLuminal, col="darkblue", xlim=c(-25,-5),ylim=c(0,1000), xlab="Probabilité",main="Probablités des trajectoires P159 N10000", add=T)
legend("topright", c("SL","Basal","Luminal"),        
    fill=c("brown3","chartreuse3","darkblue"))
plot()






